# Organización de estilos

Las hojas se cargan desde `wwwroot/index.html` en este orden:

1. `00-foundation.css`: variables, normalización, estructura y navegación general.
2. `10-inbox.css`: bandeja, chat, mensajes, adjuntos y ficha del contacto.
3. `20-crm-modules.css`: módulos operativos como contactos, tareas, ventas y reportes.
4. `30-theme-dashboard.css`: modo oscuro, correcciones compartidas y dashboard.
5. `40-marketing.css`: panel, métricas, publicaciones y comentarios de Marketing.
6. `50-responsive-overrides.css`: estructura responsive, navegación e interfaz móvil.
7. `60-hpd-reference-theme.css`: sistema visual canónico trasladado desde
   `sacar el diseño/frontend`.

El frontend de referencia es la única fuente de verdad para tipografía, color,
espaciado, estados, tablas, tarjetas y formularios. Las hojas de cada módulo deben
conservar únicamente su estructura y comportamiento particular; no deben crear un
lenguaje visual alternativo.

`login.css` pertenece exclusivamente a `wwwroot/login.html` y se carga desde esa
página; no forma parte de la cascada de la aplicación principal.

## Reglas de consistencia

- Usa las variables y componentes de `60-hpd-reference-theme.css`; evita crear
  valores visuales nuevos dentro de un módulo.
- `50-responsive-overrides.css` se reserva para disposición responsive, no para
  cambiar colores, pesos tipográficos ni apariencias de componentes.
- Breakpoints compartidos: `1100px` para tableta, `720px` para móvil y `520px`
  para pantallas compactas.
- No declares dos valores distintos de una misma propiedad para el mismo selector
  dentro del mismo contexto. Si existe una variante, usa una clase o un breakpoint.
- Los estados interactivos deben utilizar `:focus-visible` y los colores semánticos
  `--primary`, `--success`, `--warning` y `--error`.
- Los iconos de la aplicación principal y del acceso se renderizan desde
  `js/remix-icons.js`, generado a partir de `@iconify-json/ri@1.2.6`, la misma
  familia usada por `sacar el diseño/frontend`. No se debe volver a cargar
  Lucide ni mezclar otra familia de iconos.
- Los módulos sólo definen estructura y variantes semánticas. La apariencia de
  tarjetas, tablas, botones, formularios, estados y navegación pertenece a
  `60-hpd-reference-theme.css`.
